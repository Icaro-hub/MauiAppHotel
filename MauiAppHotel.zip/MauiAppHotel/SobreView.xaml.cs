namespace MauiAppHotel;

public partial class SobreView : ContentPage
{
	public SobreView()
	{
		InitializeComponent();
	}
}